package se.kth.iv1350.seminar3.integration.data;

import java.lang.Object;
/**
 * Stores all previously made sales
 */
public class SaleLogDB {
    private List<SaleDTO> saleList = new ArrayList<Object>();
    
    /**
     * Creates an instance of SaleLogDB
     */
    public SaleLogDB(){
        
    }
}
